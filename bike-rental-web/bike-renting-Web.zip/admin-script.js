const admins = [
    {
        id: "A001",
        name: "John Smith",
        role: "SuperAdmin",
        email: "john.smith@example.com",
        status: "active",
    },
    {
        id: "A002",
        name: "Jane Doe",
        role: "Moderator",
        email: "jane.doe@example.com",
        status: "inactive",
    },
    {
        id: "A003",
        name: "Bob Johnson",
        role: "Admin",
        email: "bob.johnson@example.com",
        status: "active",
    }
];

const tableBody = document.getElementById("adminTableBody");

admins.forEach(admin => {
    const row = document.createElement("tr");

    row.innerHTML = `
    <td>${admin.id}</td>
    <td>${admin.name}</td>
    <td>${admin.role}</td>
    <td>${admin.email}</td>
    <td><span class="status ${admin.status}">${admin.status.charAt(0).toUpperCase() + admin.status.slice(1)}</span></td>
    <td>
      <button class="action-btn edit-btn">Edit</button>
      <button class="action-btn delete-btn">Delete</button>
    </td>
  `;

    tableBody.appendChild(row);
});
